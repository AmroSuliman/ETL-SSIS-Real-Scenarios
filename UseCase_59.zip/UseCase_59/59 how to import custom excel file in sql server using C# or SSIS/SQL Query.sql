create table Student(Name varchar(100), DOB varchar(100), Age int)
go
select * from Student

--truncate table Student