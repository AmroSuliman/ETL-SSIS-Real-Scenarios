﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Load_Excel_file_till_a_particular_line
{
    class Program
    {
        static void Main(string[] args)
        {
            InsertExcelRecords();
        }

        public static void InsertExcelRecords()
        {
            string currentdatetime = DateTime.Now.ToString("yyyyMMddHHmmss");
            string LogFolder = @"D:\01_Personal\01-SSIS\UseCase_59\Logs";

            try
            {
                string _path = @"D:\01_Personal\01-SSIS\UseCase_59\59 how to import custom excel file in sql server using C# or SSIS\Names.xlsx";
                string constr = string.Format(
                    @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties=""Excel 12.0 Xml;HDR=YES;""",
                    _path);

                OleDbConnection Econ = new OleDbConnection(constr);
                string Query = "SELECT [Name],[DOB],[Age] FROM [Sheet1$]";
                Econ.Open();

                DataSet ds = new DataSet();
                OleDbDataAdapter oda = new OleDbDataAdapter(Query, Econ);
                Econ.Close();
                oda.Fill(ds);
                DataTable Exceldt = ds.Tables[0];

                for (int i = Exceldt.Rows.Count - 1; i >= 0; i--)
                {
                    string sr = "";
                    int ln = Exceldt.Rows[i]["Name"].ToString().Length;
                    string value = Exceldt.Rows[i]["Name"].ToString();
                    if (ln >= 4)
                    {
                        sr = Exceldt.Rows[i]["Name"].ToString().Substring(0, 4);
                    }

                    if (Exceldt.Rows[i]["Name"] == DBNull.Value ||
                        Exceldt.Rows[i]["Name"].ToString() == "" ||
                        sr == "This")
                    {
                        Exceldt.Rows[i].Delete();
                    }
                }
                Exceldt.AcceptChanges();

                // ✅ Correct connection string for default instance
                string connectionString = @"Server=.;Database=Work;Integrated Security=SSPI;";

                using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                {
                    SqlBulkCopy objbulk = new SqlBulkCopy(sqlConnection)
                    {
                        DestinationTableName = "Student"
                    };

                    objbulk.ColumnMappings.Add("Name", "Name");
                    objbulk.ColumnMappings.Add("DOB", "DOB");
                    objbulk.ColumnMappings.Add("Age", "Age");

                    sqlConnection.Open();
                    objbulk.WriteToServer(Exceldt);
                    sqlConnection.Close();
                }
            }
            catch (Exception exception)
            {
                using (StreamWriter sw = File.CreateText(LogFolder + "\\" + "ErrorLog_" + currentdatetime + ".log"))
                {
                    sw.WriteLine(exception.ToString());
                }
            }
        }
    }
}
